import mitmproxy.http
import re


def response(flow: mitmproxy.http.HTTPFlow):
    url = flow.request.url
    user_agent = flow.request.headers.get("User-Agent", "Unknown")
    
    print(f"[DEBUG] URL: {url}")
    print(f"[DEBUG] User-Agent: {user_agent}")

    content_type = flow.response.headers.get("Content-Type", "")
    if "text/html" in content_type:
        if "tng_w=staging" not in url:
            if "?" in url:
                modified_url = url + "&tng_w=staging"
            else:
                modified_url = url + "?tng_w=staging"

            flow.response.headers["Refresh"] = f"0;url={modified_url}"
            print(f"[REDIRECT] Перенаправление: {url} -> {modified_url}")
