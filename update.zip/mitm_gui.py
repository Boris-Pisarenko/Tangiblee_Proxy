import subprocess
import sys
import os
import logging
import json
import time
from PyQt6.QtWidgets import QApplication, QWidget, QPushButton, QVBoxLayout, QLabel, QCheckBox, QLineEdit, QTextEdit
from PyQt6.QtCore import Qt
from PyQt6.QtGui import QPalette, QColor, QIcon
import mitm_proxy_runner

VERSION = "1.0.1"
LOG_FILE = "mitmproxy.log"

logging.basicConfig(
    filename=LOG_FILE,
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s"
)

class ProxyGUI(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle(f"Tangiblee_Proxy v{VERSION}")
        self.setWindowIcon(QIcon("icons8-qa-64.ico"))

        self.label = QLabel(f"Прокси: выключен (v{VERSION})", self)
        self.label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.set_status_color("red")

        self.simple_proxy_checkbox = QCheckBox("Просто включить mitmproxy", self)
        self.staging_checkbox = QCheckBox("Подмена для staging PROD", self)
        self.inject_checkbox = QCheckBox("Включить Inject Script", self)

        self.domain_input = QLineEdit(self)
        self.domain_input.setPlaceholderText("Введите домен (example.com)")

        self.script_input = QTextEdit(self)
        self.script_input.setPlaceholderText("Введите JavaScript-код для инжекции")

        self.start_button = QPushButton("Старт", self)
        self.stop_button = QPushButton("Стоп", self)
        self.update_button = QPushButton("🔄 Обновить", self)
        self.cert_button = QPushButton("Установить сертификаты mitmproxy", self)
        self.cert_button.clicked.connect(self.open_certificates_page)

        layout = QVBoxLayout()
        layout.addWidget(self.label)
        layout.addWidget(self.simple_proxy_checkbox)
        layout.addWidget(self.staging_checkbox)
        layout.addWidget(self.inject_checkbox)
        layout.addWidget(QLabel("Домен для Inject Script:"))
        layout.addWidget(self.domain_input)
        layout.addWidget(QLabel("JavaScript-код:"))
        layout.addWidget(self.script_input)
        layout.addWidget(self.start_button)
        layout.addWidget(self.stop_button)
        layout.addWidget(self.update_button)
        layout.addWidget(self.cert_button, alignment=Qt.AlignmentFlag.AlignCenter)

        self.setLayout(layout)

        self.start_button.clicked.connect(self.start_proxy)
        self.stop_button.clicked.connect(self.stop_proxy)
        self.update_button.clicked.connect(self.manual_update)

        self.mitm_process = None
        logging.info(f"Запуск приложения Tangiblee_Proxy версии {VERSION}")

    def set_status_color(self, color):
        palette = self.label.palette()
        palette.setColor(QPalette.ColorRole.WindowText, QColor("green" if color == "green" else "red"))
        self.label.setPalette(palette)

    def start_proxy(self):
        if self.simple_proxy_checkbox.isChecked():
            mitm_proxy_runner.start_mitmproxy_simple()
            self.label.setText("✅ mitmproxy ВКЛЮЧЕН (без скриптов)")
            self.set_status_color("green")
            return

        scripts = []
        if self.staging_checkbox.isChecked():
            scripts.append("modify_url.py")

        if self.inject_checkbox.isChecked():
            if not self.domain_input.text().strip() or not self.script_input.toPlainText().strip():
                self.label.setText("⚠️ Введите домен и скрипт!")
                self.set_status_color("red")
                return
            self.update_inject_script()  # Заглушка для обновления скрипта инжекции
            scripts.append("inject_script.py")

        if not scripts:
            self.label.setText("⚠️ Выберите хотя бы один скрипт!")
            self.set_status_color("red")
            return

        try:
            subprocess.run([
                "reg", "add", "HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Internet Settings",
                "/v", "ProxyEnable", "/t", "REG_DWORD", "/d", "1", "/f"
            ], check=True)
            subprocess.run([
                "reg", "add", "HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Internet Settings",
                "/v", "ProxyServer", "/t", "REG_SZ", "/d", "127.0.0.1:8080", "/f"
            ], check=True)

            command = ["mitmweb", "-s"] + scripts
            self.mitm_process = subprocess.Popen(command)

            self.label.setText("✅ Прокси ВКЛЮЧЕН")
            self.set_status_color("green")
        except Exception as e:
            logging.error(f"Ошибка запуска прокси: {e}")
            self.label.setText("Ошибка запуска!")
            self.set_status_color("red")

    def stop_proxy(self):
        if self.mitm_process:
            self.mitm_process.terminate()
            self.mitm_process = None
        subprocess.run(["taskkill", "/F", "/IM", "mitmweb.exe"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        subprocess.run([
            "reg", "add", "HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Internet Settings",
            "/v", "ProxyEnable", "/t", "REG_DWORD", "/d", "0", "/f"
        ], check=True)
        self.label.setText("🔴 Прокси ВЫКЛЮЧЕН")
        self.set_status_color("red")

    def open_certificates_page(self):
        subprocess.run(["cmd", "/c", "start", "http://mitm.it/"])

    def update_inject_script(self):
        # Заглушка для обновления скрипта инжекции – реализуйте логику сохранения домена и скрипта, если требуется
        logging.info("Обновление скрипта инжекции...")

    def manual_update(self):
        # Запуск update_manager.exe для обновления
        update_exe = os.path.join(os.getcwd(), "update_manager.exe")
        if os.path.exists(update_exe):
            try:
                subprocess.Popen([update_exe])
                logging.info("Запущен update_manager.exe для обновления")
            except Exception as e:
                logging.error(f"Ошибка при запуске update_manager.exe: {e}")
        else:
            logging.error("update_manager.exe не найден!")

if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = ProxyGUI()
    window.show()
    sys.exit(app.exec())
